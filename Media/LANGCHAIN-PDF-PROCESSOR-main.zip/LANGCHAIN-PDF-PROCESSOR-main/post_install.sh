#!/bin/bash
pip install langchain_community
